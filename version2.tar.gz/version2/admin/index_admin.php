<!DOCTYPE html>

<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Cinemet Accueil Panneau d'administration</title>

  <link href="../css/reset.css" type="text/css" rel="stylesheet"/>
  <link href="../css/bootstrap.css" type="text/css" rel="stylesheet"/>
  <link href="../css/general.css" type="text/css" rel="stylesheet"/>
</head>

<body>
  <?php include "nav_admin.php"; ?>
  <center>
  <h2 class="mt-5">Cine-MET Accueil Panneau d'administration</h2>
  <img class="img_accueil_admin" src="../images/bande.png" alt="logo décoratif"/>
  </center>
</body>

</html>
