<div class="container col-md-12 border border-bottom-0 border-left-0
border-right-0 border-success mt-5">
  <div class="part1 d-flex flex-row col-md-12">

  </div>
  <div class="part2 d-flex flex-row justify-content-center col-md-12 mt-3">
    <p>©2019 Site réalisé par Simplon.co</p>
  </div>
</div>
