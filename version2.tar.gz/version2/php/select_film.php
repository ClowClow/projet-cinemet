<?php
$req = $bdd->prepare('SELECT * FROM FILM');
$req->execute();
?>
