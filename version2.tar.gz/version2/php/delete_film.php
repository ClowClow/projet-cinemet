<?php
    require "co_bdd.php";
$titre = isset($_POST['titre']) ? $_POST['titre'] : NULL;
echo $titre;
echo "/br";
 if(isset($_POST['submit'])) {

      $req = $bdd->prepare('DELETE FROM FILM WHERE id_film = :id');
      $id = $_POST['id_film'];
        $req->execute([
          'id' => $id,
        ]);

    }echo " est ce que s amache ?!!";
?>
